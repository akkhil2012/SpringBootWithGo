package com.javatechie.springbootdemo;

public class CustodianException extends RuntimeException {
    public CustodianException(String message) {
        super(message);
    }
}
