package com.javatechie.springbootdemo;

public class CustdianResponse {

    private String errorCode;
    private String errorMessage;

    public CustdianResponse(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
}
