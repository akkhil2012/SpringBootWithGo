package com.javatechie.springbootdemo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustodianService {


    @Autowired
    CustodianRepository custodianRepository;

    public Custodian createCustodian(){
        throw new CustodianException("Runtime exception...........from controller Advice");
    }

    public List<Custodian> findWithSorting(String field) {
       return custodianRepository.findAll(Sort.by(Sort.Direction.ASC, field));

    }
}
