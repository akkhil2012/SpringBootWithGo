package com.javatechie.springbootdemo;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

    Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(CustodianException.class)
    public CustodianErrorResponse exception(CustodianException e) {
        logger.warn("Inside Custodian exception......");
        CustodianErrorResponse res =  CustodianErrorResponse.builder()
                .status("FAILED due to server Error")
                .errorMessage(e.getMessage())
                .statusCode(HttpStatus.BAD_REQUEST)
                .build();
        logger.warn("Erro content ------------> " + res);
        return  res;
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public CustodianErrorResponse handleHttpMediaTypeNotSupportedException(
            HttpMediaTypeNotSupportedException ex, WebRequest request) {
        StringBuilder message = new StringBuilder("Media type not supported. Supported media types are: ");
        for (MediaType mediaType : ex.getSupportedMediaTypes()) {
            message.append(mediaType.toString()).append(", ");
        }
        // Remove the last comma and space
        if (message.length() > 0) {
            message.setLength(message.length() - 2);
        }
        CustodianErrorResponse res =  CustodianErrorResponse.builder()
                .status("This Media type is NOT supported")
                .errorMessage(ex.getMessage())
                .statusCode(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
                .build();
        logger.warn("Erro content ------------> " + res);
        return  res;
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> exception(Exception e) {
        logger.warn("Inside all exception......");
        return new ResponseEntity<>(e.getMessage(),HttpStatus.CREATED);
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<?> exception(RuntimeException e) {
        logger.warn("Inside Custom Runtime exception......");

        return new ResponseEntity<>(e.getMessage(),HttpStatus.CREATED);
    }
}
