package com.javatechie.springbootdemo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustodianRepository extends JpaRepository<Custodian,Long> {

}
