package com.javatechie.springbootdemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;


@RestController
@RequestMapping("/v1/custodian")
public class CustodianController {

    @Autowired
    JWTService jwtService;

    @Autowired
    CustodianService custodianService;

    @Autowired
    CustodianRepository custodianRepository;

    Map<Long,Custodian> mp = new HashMap<>();

    static AtomicLong sequence = new AtomicLong(1l);

    Logger logger = LoggerFactory.getLogger(CustodianController.class);

   /* @GetMapping("/custodians")
    public ResponseEntity<?> fetcheCustodian(){

        logger.info("Fetch the custodian........");

       Custodian custodian =  custodianService.createCustodian();
        return ResponseEntity.ok(custodian);
    }*/


    // raw data using curl NOT fetched using the @RequestBody but by @requestParam
    /*@PostMapping(value="/custodians",consumes = "application/x-www-form-urlencoded")
    public ResponseEntity<?> createCustodian(@RequestBody Custodian request){

        Custodian custodian = new Custodian();
        //  custodian.setId(request.getId());
        custodian.setName(request.getName());

        logger.info("Created the custodian........");
        return ResponseEntity.ok(custodian);
    }*/

    @PostMapping(value="/custodians")
    public ResponseEntity<?> createCustodian(@RequestParam(value="name") String name){

        Custodian custodian = new Custodian();
        custodian.setName(name);

        long id = sequence.getAndIncrement();
        custodian.setId(id);
        //custodian.setCreatedDate();

     //   mp.put(id,custodian);
        custodianRepository.save(custodian);


        logger.info("Created the custodian........");
        return ResponseEntity.ok(custodian);
    }


    @GetMapping("/custodians")
    public ResponseEntity<List<Custodian>> fetchOptionalCustodian(@RequestParam(value="id",required = false) Long id){
        Custodian custodian;
        List<Custodian> custodians = new ArrayList<>();

      //  custodian =custodianRepository.findAll();
     //   custodians.add(custodian);
        if(id!=null){
            custodian = custodianRepository.findById(id).get();
            custodians.add(custodian);
        }else{
          //  custodian = (Custodian) mp.values();
            custodians.addAll(custodianRepository.findAll());
        }
       // custodians.add(custodian);
        return ResponseEntity.ok(custodians);
    }


    @GetMapping("/custodians/{field}")
    public ResponseEntity<List<Custodian>> fetchCustodianByField(@PathVariable(value="field") String field){
        Custodian custodian;
        List<Custodian> custodians = new ArrayList<>();
        custodians = custodianService.findWithSorting(field);
        return ResponseEntity.ok(custodians);
    }


    @PostMapping("/authenticate")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest){
        String token =   jwtService.generateToken(authRequest.getUsername());
        logger.info("JWT created is-----------------> "+ token);
        return token;
    }
}
